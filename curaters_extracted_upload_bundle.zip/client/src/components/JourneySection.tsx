import { useState } from "react";
import { ArrowUpRight, CalendarDays, Compass, Gem, Users, Sparkles } from "lucide-react";
import { bookingPlans, legacyOffers, type PackageType } from "@/data/travelPackages";

const icons = { day: CalendarDays, group: Users, private: Gem, hosted: Sparkles };

export default function JourneySection({ onBook }: { onBook: (plan: PackageType) => void }) {
  const [activePlan, setActivePlan] = useState<PackageType | "all">("all");
  const [accessMessage, setAccessMessage] = useState("");
  const offers = legacyOffers.filter((offer) => activePlan === "all" || offer.plan === activePlan);

  return (
    <section className="journey-section section-shell" id="journeys" aria-labelledby="journeys-heading">
      <div className="section-heading journey-heading">
        <div>
          <p className="eyebrow">Choose your kind of journey</p>
          <h2 id="journeys-heading">Travel, <em>your way.</em></h2>
        </div>
        <p className="section-intro">A little structure for the planning. Plenty of room for the unexpected.</p>
      </div>
      <div className="plan-grid">
        {bookingPlans.map((plan, index) => {
          const Icon = icons[plan.icon];
          return (
            <article className={`plan-card plan-card-${plan.id}`} key={plan.id}>
              <div className="plan-topline"><span className="plan-index">0{index + 1}</span><Icon size={20} strokeWidth={1.5} aria-hidden="true" /></div>
              <p className="eyebrow">{plan.eyebrow}</p>
              <h3>{plan.title}</h3>
              <p>{plan.description}</p>
              <button className="plan-link" type="button" onClick={() => onBook(plan.id)}>Plan this trip <ArrowUpRight size={16} /></button>
            </article>
          );
        })}
      </div>

      <div className="offers-heading">
        <div>
          <p className="eyebrow">Curated experiences</p>
          <h3>From the <em>Curaters collection.</em></h3>
        </div>
        <div className="offer-filters" role="group" aria-label="Filter trip packages">
          {[{ id: "all", title: "All" }, ...bookingPlans.map(({ id, title }) => ({ id, title }))].map((item) => (
            <button key={item.id} type="button" className={activePlan === item.id ? "is-active" : ""} aria-pressed={activePlan === item.id} onClick={() => setActivePlan(item.id as PackageType | "all")}>{item.title}</button>
          ))}
        </div>
      </div>

      <div className="offer-grid">
        {offers.map((offer) => (
          <article className="offer-card" key={offer.id}>
            <a className="offer-photo" href={offer.detailUrl} target="_blank" rel="noreferrer" aria-label={`View original details for ${offer.title}`}>
              <img src={offer.image} alt={`${offer.title} travel experience`} loading="lazy" width="800" height="560" />
              <span className="offer-tag">{offer.eyebrow}</span>
              {offer.status && <span className="offer-status">{offer.status}</span>}
            </a>
            <div className="offer-body">
              <p className="offer-availability">{offer.availability}</p>
              <h4>{offer.title}</h4>
              <p className="offer-description">{offer.description}</p>
              <div className="offer-footer"><strong>{offer.price}</strong><span>Listed price</span></div>
              <div className="offer-actions">
                <a className="button button-quiet" href={offer.detailUrl} target="_blank" rel="noreferrer">Original details <ArrowUpRight size={14} /></a>
                <button className="button button-outline" type="button" onClick={() => onBook(offer.plan)}>Book <ArrowUpRight size={14} /></button>
              </div>
            </div>
          </article>
        ))}
      </div>
      {!offers.length && <p className="empty-results">No packages in this category yet.</p>}

      <div className="private-access-card">
        <div className="private-access-copy">
          <p className="eyebrow">Private journeys</p>
          <h3>Private Access Required</h3>
          <p>These exclusive private experiences are only available to verified guests with authorized access.</p>
          <p className="access-note">The supplied preview does not include an access-key verification service. A key entered here stays on this device and is not transmitted or saved.</p>
        </div>
        <form className="access-form" onSubmit={(event) => { event.preventDefault(); setAccessMessage("Access-key verification is not available in this preview. Your key was not sent or saved. You can continue with a private-trip enquiry below."); onBook("private_trips"); }}>
          <label htmlFor="private-access-key">Enter Access Key</label>
          <input id="private-access-key" type="password" autoComplete="off" placeholder="Private access key" />
          <button className="button button-primary" type="submit">Continue to private enquiry <ArrowUpRight size={16} /></button>
          {accessMessage && <p className="access-feedback" role="status">{accessMessage}</p>}
          <a className="access-email" href="mailto:travelcuraters@gmail.com">Need help? Email Curaters</a>
        </form>
      </div>
      <p className="price-note">Listed prices and availability are shown as supplied. A submitted request is not a confirmed reservation.</p>
    </section>
  );
}
