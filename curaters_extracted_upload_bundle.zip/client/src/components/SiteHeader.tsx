import { useState } from "react";
import { ArrowUpRight, Menu, X } from "lucide-react";

const links = [
  { href: "#destinations", label: "Destinations" },
  { href: "#journeys", label: "Journeys" },
  { href: "#story", label: "Our story" },
  { href: "#faq", label: "FAQs" },
];

export default function SiteHeader() {
  const [open, setOpen] = useState(false);
  const closeMenu = () => setOpen(false);

  return (
    <header className="site-header">
      <div className="header-inner">
        <a className="brand-lockup" href="#top" aria-label="Curaters home" onClick={closeMenu}>
          <span className="brand-mark" aria-hidden="true">C</span>
          <span className="brand-wordmark">curaters<span className="brand-period">.</span></span>
        </a>
        <nav id="mobile-navigation" className={`main-nav${open ? " is-open" : ""}`} aria-label="Main navigation">
          {links.map((link) => (
            <a key={link.href} href={link.href} onClick={closeMenu}>{link.label}</a>
          ))}
          <a className="nav-book" href="#book" onClick={closeMenu}>
            Plan a trip <ArrowUpRight size={16} aria-hidden="true" />
          </a>
        </nav>
        <button
          className="menu-toggle"
          type="button"
          aria-label={open ? "Close menu" : "Open menu"}
          aria-expanded={open}
          aria-controls="mobile-navigation"
          onClick={() => setOpen((value) => !value)}
        >
          {open ? <X size={22} /> : <Menu size={22} />}
        </button>
      </div>
      {open && <button className="menu-backdrop" aria-label="Close navigation menu" onClick={closeMenu} />}
    </header>
  );
}
