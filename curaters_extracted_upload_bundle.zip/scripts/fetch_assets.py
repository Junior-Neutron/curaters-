from __future__ import annotations

import base64
import html
import json
import re
import shutil
import time
import urllib.parse
import urllib.request
from io import BytesIO
from pathlib import Path

from PIL import Image

PROJECT = Path(__file__).resolve().parents[1]
SOURCE = Path('/home/ubuntu/curaters-inspect')
PUBLIC = PROJECT / 'client/public/images'
DEST = PUBLIC / 'destinations'
LEGACY = PUBLIC / 'legacy'
DEST.mkdir(parents=True, exist_ok=True)
LEGACY.mkdir(parents=True, exist_ok=True)

DESTINATIONS = [
    ('cape-coast-castle', 'Cape Coast Castle'),
    ('kakum-national-park', 'Kakum National Park'),
    ('mole-national-park', 'Mole National Park'),
    ('wli-waterfalls', 'Wli Waterfalls'),
    ('maasai-mara', 'Maasai Mara'),
    ('diani-beach', 'Diani beach white sands'),
    ('serengeti', 'Serengeti National Park'),
    ('mount-kilimanjaro', 'Mount Kilimanjaro'),
    ('zanzibar', 'Zanzibar Stone Town'),
    ('cape-town', 'Cape Town skyline South Africa'),
    ('table-mountain', 'Table Mountain Cape Town'),
    ('kruger-national-park', 'Kruger National Park'),
    ('pyramids-of-giza', 'Pyramids of Giza'),
    ('luxor', 'Luxor Egypt'),
    ('marrakech', 'Marrakech Koutoubia Mosque'),
    ('chefchaouen', 'Chefchaouen blue medina'),
    ('sahara-desert', 'Erg Chebbi Morocco'),
    ('victoria-falls', 'Victoria Falls'),
    ('bwindi-impenetrable-forest', 'Bwindi forest'),
    ('volcanoes-national-park', 'Gahinga volcano Rwanda'),
    ('sossusvlei', 'Sossusvlei'),
    ('goree-island', 'Gorée Island Senegal'),
]

USER_AGENT = 'CuratersTravelSite/1.0 (photo sourcing; contact travelcuraters@gmail.com)'
AVOID = re.compile(r'\b(obama|trump|melania|president|first lady|politician|portrait|selfie|map|diagram|war|bicycle|bike|delivery|guy|dassie|bird|babbler|bee.?eater|mole rat|babuchas|slippers?|akchour|waterfall|ranger|machine gun|rifle|weapon|coat of arms|logo)\b', re.I)
STOP = {'the', 'of', 'and', 'national', 'park', 'island', 'mount', 'mountain', 'forest', 'ghana', 'kenya', 'tanzania', 'south', 'africa', 'egypt', 'morocco', 'rwanda', 'uganda', 'namibia', 'senegal', 'zimbabwe', 'zambia', 'desert', 'falls', 'cape', 'beach'}
REFRESH = {'diani-beach', 'zanzibar', 'cape-town', 'marrakech', 'chefchaouen', 'bwindi-impenetrable-forest', 'volcanoes-national-park'}

def get_json(url: str) -> dict:
    request = urllib.request.Request(url, headers={'User-Agent': USER_AGENT})
    with urllib.request.urlopen(request, timeout=30) as response:
        return json.load(response)

def clean_html(value: str) -> str:
    return re.sub(r'\s+', ' ', re.sub(r'<[^>]+>', ' ', html.unescape(value))).strip()

def optimize(raw: bytes, output: Path, max_width: int = 1500) -> None:
    image = Image.open(BytesIO(raw))
    image.thumbnail((max_width, max_width), Image.Resampling.LANCZOS)
    if image.mode not in ('RGB', 'RGBA'):
        image = image.convert('RGB')
    image.save(output, 'WEBP', quality=84, method=6)

def image_candidates(query: str) -> list[dict]:
    for search in (f'filetype:bitmap "{query}"', f'filetype:bitmap {query}', query):
        params = {
            'action': 'query', 'format': 'json', 'generator': 'search',
            'gsrsearch': search, 'gsrnamespace': 6, 'gsrlimit': 20,
            'prop': 'imageinfo', 'iiprop': 'url|extmetadata|mime', 'iiurlwidth': 1200,
        }
        data = get_json('https://commons.wikimedia.org/w/api.php?' + urllib.parse.urlencode(params))
        pages = list(data.get('query', {}).get('pages', {}).values())
        if pages:
            return pages
    return []

def fetch_destination(slug: str, query: str) -> dict:
    pages = image_candidates(query)
    if not pages:
        raise RuntimeError(f'No Wikimedia Commons search results for {query}')
    terms = [t.lower() for t in re.findall(r'[a-zA-Z0-9]+', query) if t.lower() not in STOP]
    candidates = []
    for page in pages:
        info = (page.get('imageinfo') or [{}])[0]
        title = page.get('title', '')
        if not info.get('thumburl') or AVOID.search(title):
            continue
        title_tokens = set(re.findall(r'[a-z0-9]+', title.lower()))
        score = sum(2 for term in terms if term in title_tokens)
        candidates.append((score, page, info))
    if not candidates:
        raise RuntimeError(f'No usable image results for {query}')
    candidates.sort(key=lambda row: row[0], reverse=True)
    _, page, info = candidates[0]
    request = urllib.request.Request(info['thumburl'], headers={'User-Agent': USER_AGENT})
    with urllib.request.urlopen(request, timeout=30) as response:
        raw = response.read()
    out = DEST / f'{slug}.webp'
    optimize(raw, out)
    meta = info.get('extmetadata', {})
    artist = clean_html(meta.get('Artist', {}).get('value', ''))
    credit = clean_html(meta.get('Credit', {}).get('value', ''))
    return {
        'slug': slug,
        'file': f'/images/destinations/{slug}.webp',
        'title': page.get('title', '').removeprefix('File:'),
        'source': info.get('descriptionurl', ''),
        'imageSource': info.get('thumburl', ''),
        'artist': artist or credit or 'Wikimedia Commons contributor',
        'license': clean_html(meta.get('LicenseShortName', {}).get('value', 'See source page')),
        'licenseUrl': meta.get('LicenseUrl', {}).get('value', ''),
    }

def preserve_legacy_photos() -> list[dict]:
    saved = []
    for page in ('index.html', 'group-trips.html', 'hosted-trips.html'):
        text = (SOURCE / page).read_text(errors='ignore')
        found = re.findall(r'<img[^>]*src=["\']data:image/([^;]+);base64,([^"\']+)', text, flags=re.I)
        page_key = {'index.html': 'day-trips', 'group-trips.html': 'group-trips', 'hosted-trips.html': 'hosted-trips'}[page]
        for index, (mime, encoded) in enumerate(found, start=1):
            try:
                slug = f'{page_key}-{index}'
                optimize(base64.b64decode(encoded), LEGACY / f'{slug}.webp')
                saved.append({'slug': slug, 'file': f'/images/legacy/{slug}.webp', 'sourcePage': page, 'sourceMime': mime})
            except Exception as exc:
                print(f'Could not preserve {page} embedded image {index}: {exc}')
    return saved

def main() -> None:
    brand = PUBLIC / 'brand'
    brand.mkdir(parents=True, exist_ok=True)
    for name in ('logo.png', 'logo-2.png'):
        shutil.copy2(SOURCE / 'assets/images' / name, brand / name)
    legacy = preserve_legacy_photos()
    existing = json.loads((DEST / 'attributions.json').read_text()) if (DEST / 'attributions.json').exists() else []
    sources_by_slug = {item['slug']: item for item in existing}
    for index, (slug, query) in enumerate(DESTINATIONS, start=1):
        if slug not in REFRESH and (DEST / f'{slug}.webp').exists() and slug in sources_by_slug:
            continue
        try:
            source = fetch_destination(slug, query)
            sources_by_slug[slug] = source
            print(f"{index:02d}/22 {slug}: {source['title']} [{source['license']}]")
        except Exception as exc:
            print(f'{index:02d}/22 FAILED {slug}: {exc}')
        time.sleep(0.3)
    sources = [sources_by_slug[slug] for slug, _ in DESTINATIONS if slug in sources_by_slug]
    (DEST / 'attributions.json').write_text(json.dumps(sources, ensure_ascii=False, indent=2) + '\n')
    (LEGACY / 'manifest.json').write_text(json.dumps(legacy, ensure_ascii=False, indent=2) + '\n')
    print(f'Finished: {len(sources)}/22 destination images; preserved {len(legacy)} legacy offer photos.')

if __name__ == '__main__':
    main()
