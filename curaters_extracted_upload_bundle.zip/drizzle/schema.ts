import { date, int, mysqlEnum, mysqlTable, text, timestamp, varchar } from "drizzle-orm/mysql-core";

/**
 * Core user table backing auth flow.
 * Extend this file with additional tables as your product grows.
 * Columns use camelCase to match both database fields and generated types.
 */
export const users = mysqlTable("users", {
  id: int("id").autoincrement().primaryKey(),
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

/** Private booking records. There is intentionally no public read/list procedure. */
export const bookings = mysqlTable("bookings", {
  id: int("id").autoincrement().primaryKey(),
  reference: varchar("reference", { length: 20 }).notNull().unique(),
  fullName: varchar("fullName", { length: 160 }).notNull(),
  email: varchar("email", { length: 320 }).notNull(),
  phone: varchar("phone", { length: 48 }).notNull(),
  country: varchar("country", { length: 120 }).notNull(),
  destination: varchar("destination", { length: 140 }).notNull(),
  packageType: mysqlEnum("packageType", ["day_trips", "group_trips", "private_trips", "hosted_trips"]).notNull(),
  travelStart: date("travelStart", { mode: "string" }).notNull(),
  travelEnd: date("travelEnd", { mode: "string" }).notNull(),
  adults: int("adults").notNull(),
  children: int("children").notNull().default(0),
  accommodationPreference: varchar("accommodationPreference", { length: 120 }).notNull(),
  budget: varchar("budget", { length: 120 }),
  activities: text("activities").notNull(),
  specialRequests: text("specialRequests"),
  preferredContact: mysqlEnum("preferredContact", ["email", "phone", "whatsapp"]).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type Booking = typeof bookings.$inferSelect;
export type InsertBooking = typeof bookings.$inferInsert;
