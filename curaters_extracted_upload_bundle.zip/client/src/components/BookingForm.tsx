import { useEffect, useMemo, useState, type FormEvent, type ChangeEvent } from "react";
import { ArrowRight, CalendarDays, Check, LockKeyhole, MapPin, Send, Users } from "lucide-react";
import { destinations, type Destination } from "@/data/destinations";
import { bookingPlans, type PackageType } from "@/data/travelPackages";
import { trpc } from "@/lib/trpc";

type Values = {
  fullName: string;
  email: string;
  phone: string;
  country: string;
  destination: string;
  packageType: PackageType | "";
  travelStart: string;
  travelEnd: string;
  adults: string;
  children: string;
  accommodationPreference: string;
  budget: string;
  activities: string[];
  specialRequests: string;
  preferredContact: "email" | "phone" | "whatsapp" | "";
};

type ErrorMap = Partial<Record<keyof Values, string>>;

const emptyValues: Values = {
  fullName: "", email: "", phone: "", country: "", destination: "", packageType: "",
  travelStart: "", travelEnd: "", adults: "1", children: "0", accommodationPreference: "",
  budget: "", activities: [], specialRequests: "", preferredContact: "",
};

const generalActivities = ["Culture & history", "Wildlife & nature", "Beach & coast", "Food & markets", "Adventure", "Not sure yet"];
const packageNames: Record<PackageType, string> = {
  day_trips: "Day trips", group_trips: "Group trips", private_trips: "Private trips", hosted_trips: "Hosted trips",
};

export default function BookingForm({ initialDestination, initialPackage, onClearSelection }: {
  initialDestination: Destination | null;
  initialPackage: PackageType;
  onClearSelection: () => void;
}) {
  const [values, setValues] = useState<Values>({ ...emptyValues, packageType: initialPackage });
  const [errors, setErrors] = useState<ErrorMap>({});
  const [reference, setReference] = useState("");
  const [submitError, setSubmitError] = useState("");
  const submitMutation = trpc.bookings.create.useMutation();

  useEffect(() => {
    if (!initialDestination) return;
    setValues((current) => ({ ...current, destination: initialDestination.name, activities: [] }));
    setErrors((current) => ({ ...current, destination: undefined, activities: undefined }));
    setReference("");
    setSubmitError("");
  }, [initialDestination]);

  useEffect(() => {
    setValues((current) => ({ ...current, packageType: initialPackage }));
    setErrors((current) => ({ ...current, packageType: undefined }));
    setReference("");
    setSubmitError("");
  }, [initialPackage]);

  const selectedDestination = destinations.find((item) => item.name === values.destination);
  const activityOptions = selectedDestination?.activities ?? generalActivities;
  const planLabel = values.packageType ? packageNames[values.packageType] : "Choose a trip style";
  const selectedCountry = selectedDestination?.country;
  const travelerCount = (Number(values.adults) || 0) + (Number(values.children) || 0);
  const startLabel = useMemo(() => formatDate(values.travelStart), [values.travelStart]);
  const endLabel = useMemo(() => formatDate(values.travelEnd), [values.travelEnd]);

  function update<K extends keyof Values>(key: K, value: Values[K]) {
    setValues((current) => ({ ...current, [key]: value }));
    setErrors((current) => ({ ...current, [key]: undefined }));
    setReference("");
    setSubmitError("");
  }

  function updateDestination(value: string) {
    setValues((current) => ({ ...current, destination: value, activities: [] }));
    setErrors((current) => ({ ...current, destination: undefined, activities: undefined }));
    setReference("");
    setSubmitError("");
  }

  function validate(): ErrorMap {
    const next: ErrorMap = {};
    if (values.fullName.trim().length < 2) next.fullName = "Enter your full name.";
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(values.email.trim())) next.email = "Enter a valid email address.";
    if (values.phone.trim().replace(/\D/g, "").length < 7) next.phone = "Enter a valid phone number.";
    if (values.country.trim().length < 2) next.country = "Enter your country.";
    if (!values.destination) next.destination = "Choose a destination.";
    if (!values.packageType) next.packageType = "Choose a trip style.";
    if (!values.travelStart) next.travelStart = "Choose a start date.";
    if (!values.travelEnd) next.travelEnd = "Choose a return date.";
    if (values.travelStart && values.travelEnd && values.travelEnd < values.travelStart) next.travelEnd = "Return date must be on or after the start date.";
    if (!values.adults || Number(values.adults) < 1 || Number(values.adults) > 30) next.adults = "Enter at least 1 adult.";
    if (values.children === "" || Number(values.children) < 0 || Number(values.children) > 30) next.children = "Enter 0 or more children.";
    if (!values.accommodationPreference) next.accommodationPreference = "Choose an accommodation preference.";
    if (!values.activities.length) next.activities = "Choose at least one activity or select ‘Not sure yet’.";
    if (!values.preferredContact) next.preferredContact = "Choose how you prefer to be contacted.";
    return next;
  }

  async function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setReference("");
    setSubmitError("");
    const nextErrors = validate();
    setErrors(nextErrors);
    if (Object.keys(nextErrors).length) {
      document.querySelector<HTMLElement>("[aria-invalid='true']")?.focus();
      return;
    }
    try {
      const result = await submitMutation.mutateAsync({
        fullName: values.fullName.trim(),
        email: values.email.trim(),
        phone: values.phone.trim(),
        country: values.country.trim(),
        destination: values.destination,
        packageType: values.packageType as PackageType,
        travelStart: values.travelStart,
        travelEnd: values.travelEnd,
        adults: Number(values.adults),
        children: Number(values.children),
        accommodationPreference: values.accommodationPreference,
        budget: values.budget.trim(),
        activities: values.activities,
        specialRequests: values.specialRequests.trim(),
        preferredContact: values.preferredContact as "email" | "phone" | "whatsapp",
      });
      setReference(result.reference);
      setErrors({});
      onClearSelection();
    } catch {
      setSubmitError("Your request could not be saved. Please try again, or email travelcuraters@gmail.com. No booking has been confirmed.");
    }
  }

  const errorId = (field: keyof Values) => errors[field] ? `${field}-error` : undefined;
  const errorText = (field: keyof Values) => errors[field] ? <span className="field-error" id={errorId(field)}>{errors[field]}</span> : null;
  const invalid = (field: keyof Values) => errors[field] ? true : undefined;

  return (
    <section className="booking-section section-shell" id="book" aria-labelledby="booking-heading">
      <div className="booking-heading section-heading">
        <div>
          <p className="eyebrow">A good trip starts with a conversation</p>
          <h2 id="booking-heading" tabIndex={-1}>Let’s make it <em>yours.</em></h2>
        </div>
        <p className="section-intro">Share the details you know. Your request is only recorded when the form confirms it has been saved.</p>
      </div>

      <div className="booking-layout">
        <form className="booking-form" onSubmit={handleSubmit} noValidate>
          <fieldset className="form-fieldset">
            <legend><span className="form-step">01</span> Your details</legend>
            <div className="form-grid">
              <div className="form-field full-field">
                <label htmlFor="fullName">Full name <span className="required-star">*</span></label>
                <input id="fullName" name="fullName" autoComplete="name" value={values.fullName} onChange={(e) => update("fullName", e.target.value)} aria-invalid={invalid("fullName")} aria-describedby={errorId("fullName")} required />
                {errorText("fullName")}
              </div>
              <div className="form-field">
                <label htmlFor="email">Email address <span className="required-star">*</span></label>
                <input id="email" name="email" type="email" autoComplete="email" value={values.email} onChange={(e) => update("email", e.target.value)} aria-invalid={invalid("email")} aria-describedby={errorId("email")} required />
                {errorText("email")}
              </div>
              <div className="form-field">
                <label htmlFor="phone">Phone number <span className="required-star">*</span></label>
                <input id="phone" name="phone" type="tel" autoComplete="tel" value={values.phone} onChange={(e) => update("phone", e.target.value)} aria-invalid={invalid("phone")} aria-describedby={errorId("phone")} required />
                {errorText("phone")}
              </div>
              <div className="form-field full-field">
                <label htmlFor="country">Your country <span className="required-star">*</span></label>
                <input id="country" name="country" autoComplete="country-name" placeholder="Country of residence" value={values.country} onChange={(e) => update("country", e.target.value)} aria-invalid={invalid("country")} aria-describedby={errorId("country")} required />
                {errorText("country")}
              </div>
            </div>
          </fieldset>

          <fieldset className="form-fieldset">
            <legend><span className="form-step">02</span> Your journey</legend>
            <div className="form-grid">
              <div className="form-field">
                <label htmlFor="destination">Destination <span className="required-star">*</span></label>
                <select id="destination" name="destination" value={values.destination} onChange={(e) => updateDestination(e.target.value)} aria-invalid={invalid("destination")} aria-describedby={errorId("destination")} required>
                  <option value="">Select a destination</option>
                  {destinations.map((item) => <option key={item.slug} value={item.name}>{item.name} · {item.country}</option>)}
                </select>
                {errorText("destination")}
              </div>
              <div className="form-field">
                <label htmlFor="packageType">Trip style <span className="required-star">*</span></label>
                <select id="packageType" name="packageType" value={values.packageType} onChange={(e) => update("packageType", e.target.value as PackageType | "")} aria-invalid={invalid("packageType")} aria-describedby={errorId("packageType")} required>
                  <option value="">Choose a trip style</option>
                  {bookingPlans.map((plan) => <option key={plan.id} value={plan.id}>{plan.title}</option>)}
                </select>
                {errorText("packageType")}
              </div>
              <div className="form-field">
                <label htmlFor="travelStart">Travel dates · start <span className="required-star">*</span></label>
                <div className="input-with-icon"><CalendarDays size={17} aria-hidden="true" /><input id="travelStart" name="travelStart" type="date" value={values.travelStart} onChange={(e) => update("travelStart", e.target.value)} aria-invalid={invalid("travelStart")} aria-describedby={errorId("travelStart")} required /></div>
                {errorText("travelStart")}
              </div>
              <div className="form-field">
                <label htmlFor="travelEnd">Travel dates · return <span className="required-star">*</span></label>
                <div className="input-with-icon"><CalendarDays size={17} aria-hidden="true" /><input id="travelEnd" name="travelEnd" type="date" value={values.travelEnd} onChange={(e) => update("travelEnd", e.target.value)} aria-invalid={invalid("travelEnd")} aria-describedby={errorId("travelEnd")} required /></div>
                {errorText("travelEnd")}
              </div>
              <div className="form-field">
                <label htmlFor="adults">Adults <span className="required-star">*</span></label>
                <div className="input-with-icon"><Users size={17} aria-hidden="true" /><input id="adults" name="adults" type="number" min="1" max="30" value={values.adults} onChange={(e) => update("adults", e.target.value)} aria-invalid={invalid("adults")} aria-describedby={errorId("adults")} required /></div>
                {errorText("adults")}
              </div>
              <div className="form-field">
                <label htmlFor="children">Children</label>
                <div className="input-with-icon"><Users size={17} aria-hidden="true" /><input id="children" name="children" type="number" min="0" max="30" value={values.children} onChange={(e) => update("children", e.target.value)} aria-invalid={invalid("children")} aria-describedby={errorId("children")} /></div>
                {errorText("children")}
              </div>
              <div className="form-field full-field">
                <label htmlFor="accommodationPreference">Accommodation preference <span className="required-star">*</span></label>
                <select id="accommodationPreference" name="accommodationPreference" value={values.accommodationPreference} onChange={(e) => update("accommodationPreference", e.target.value)} aria-invalid={invalid("accommodationPreference")} aria-describedby={errorId("accommodationPreference")} required>
                  <option value="">Choose a preference</option>
                  <option value="No preference">No preference</option>
                  <option value="Hotel">Hotel</option>
                  <option value="Lodge">Lodge</option>
                  <option value="Resort">Resort</option>
                  <option value="Guesthouse">Guesthouse</option>
                  <option value="Other">Other</option>
                </select>
                {errorText("accommodationPreference")}
              </div>
              <div className="form-field full-field">
                <label htmlFor="budget">Budget <span className="optional-label">Optional</span></label>
                <input id="budget" name="budget" type="text" placeholder="Share a preferred range or currency" value={values.budget} onChange={(e) => update("budget", e.target.value)} aria-invalid={invalid("budget")} aria-describedby={errorId("budget")} />
                {errorText("budget")}
              </div>
            </div>
          </fieldset>

          <fieldset className="form-fieldset">
            <legend><span className="form-step">03</span> The details that make it yours</legend>
            <div className="form-field full-field activity-field">
              <label>Activities <span className="required-star">*</span></label>
              <p className="field-hint">Choose at least one, or select “Not sure yet”.</p>
              <div className="activity-options" role="group" aria-label="Activities" aria-invalid={invalid("activities")} aria-describedby={errorId("activities")}>
                {activityOptions.map((activity) => {
                  const checked = values.activities.includes(activity);
                  return <label className={`activity-pill${checked ? " is-selected" : ""}`} key={activity}>
                    <input type="checkbox" checked={checked} onChange={() => update("activities", checked ? values.activities.filter((item) => item !== activity) : [...values.activities, activity])} />
                    <span>{activity}</span>
                  </label>;
                })}
              </div>
              {errorText("activities")}
            </div>
            <div className="form-field full-field">
              <label htmlFor="specialRequests">Special requests <span className="optional-label">Optional</span></label>
              <textarea id="specialRequests" name="specialRequests" rows={4} maxLength={3000} placeholder="Anything else you would like us to know?" value={values.specialRequests} onChange={(e) => update("specialRequests", e.target.value)} aria-invalid={invalid("specialRequests")} aria-describedby={errorId("specialRequests")} />
              <span className="field-hint character-count">{values.specialRequests.length}/3000</span>
              {errorText("specialRequests")}
            </div>
            <div className="form-field full-field">
              <label htmlFor="preferredContact">Preferred contact method <span className="required-star">*</span></label>
              <select id="preferredContact" name="preferredContact" value={values.preferredContact} onChange={(e) => update("preferredContact", e.target.value as Values["preferredContact"])} aria-invalid={invalid("preferredContact")} aria-describedby={errorId("preferredContact")} required>
                <option value="">Choose how to reach you</option>
                <option value="email">Email</option>
                <option value="phone">Phone call</option>
                <option value="whatsapp">WhatsApp</option>
              </select>
              {errorText("preferredContact")}
            </div>
          </fieldset>

          {submitError && <div className="form-alert form-alert-error" role="alert">{submitError}</div>}
          {reference && <div className="form-alert form-alert-success" role="status" aria-live="polite"><Check size={20} /><div><strong>Your request was saved.</strong><span>Reference {reference}. This is a trip request, not a confirmed reservation or payment.</span></div></div>}
          <p className="form-privacy"><LockKeyhole size={15} aria-hidden="true" /> Your details are sent to the booking service over the app’s server connection; saved requests are not exposed in a public booking list.</p>
          <button className="button button-primary submit-booking" type="submit" disabled={submitMutation.isPending}>
            {submitMutation.isPending ? "Saving your request…" : "Send trip request"}
            {!submitMutation.isPending && <Send size={16} aria-hidden="true" />}
          </button>
          <p className="submit-footnote">A saved request is not a confirmed reservation. If you need help, email <a href="mailto:travelcuraters@gmail.com">travelcuraters@gmail.com</a>.</p>
        </form>

        <aside className="booking-summary" aria-labelledby="summary-heading">
          <div className="summary-top"><p className="eyebrow">Your trip at a glance</p><h3 id="summary-heading">A first <em>sketch.</em></h3><p>Keep an eye on the details as you shape your request.</p></div>
          <div className="summary-image-wrap">
            {selectedDestination ? <img src={selectedDestination.image} alt={selectedDestination.imageAlt} width="720" height="460" /> : <div className="summary-image-placeholder"><CompassIcon /></div>}
            {selectedDestination && <span><MapPin size={14} /> {selectedCountry}</span>}
          </div>
          <dl className="summary-list">
            <div><dt>Destination</dt><dd>{selectedDestination?.name || "Choose a place"}</dd></div>
            <div><dt>Trip style</dt><dd>{planLabel}</dd></div>
            <div><dt>Travel dates</dt><dd>{startLabel && endLabel ? `${startLabel} — ${endLabel}` : "Choose your dates"}</dd></div>
            <div><dt>Travellers</dt><dd>{travelerCount ? `${travelerCount} ${travelerCount === 1 ? "traveller" : "travellers"}` : "Add your group"}</dd></div>
            <div><dt>Accommodation</dt><dd>{values.accommodationPreference || "Choose a preference"}</dd></div>
          </dl>
          <div className="summary-footer"><span className="summary-dot" /> Nothing is reserved until your request is reviewed.</div>
        </aside>
      </div>
    </section>
  );
}

function formatDate(value: string) {
  if (!value) return "";
  const date = new Date(`${value}T00:00:00`);
  return Number.isNaN(date.valueOf()) ? "" : new Intl.DateTimeFormat("en", { day: "numeric", month: "short", year: "numeric" }).format(date);
}

function CompassIcon() {
  return <span className="summary-compass" aria-hidden="true"><MapPin size={30} strokeWidth={1.3} /></span>;
}
