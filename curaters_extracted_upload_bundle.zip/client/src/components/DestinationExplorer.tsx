import { useEffect, useMemo, useState } from "react";
import { ArrowRight, ArrowUpRight, ChevronDown, MapPin, Search, X } from "lucide-react";
import { destinations, destinationCategories, destinationCountries, type Destination } from "@/data/destinations";

export type PhotoCredit = { slug: string; title: string; source: string; artist: string; license: string; licenseUrl?: string };

type Props = { onBook: (destination: Destination) => void };

export default function DestinationExplorer({ onBook }: Props) {
  const [search, setSearch] = useState("");
  const [country, setCountry] = useState("All countries");
  const [category, setCategory] = useState("All experiences");
  const [selected, setSelected] = useState<Destination | null>(null);
  const [credits, setCredits] = useState<Record<string, PhotoCredit>>({});

  useEffect(() => {
    fetch("/images/destinations/attributions.json")
      .then((response) => (response.ok ? response.json() : []))
      .then((items: PhotoCredit[]) => setCredits(Object.fromEntries(items.map((item) => [item.slug, item]))))
      .catch(() => setCredits({}));
  }, []);

  useEffect(() => {
    if (!selected) return;
    const oldOverflow = document.body.style.overflow;
    const previousFocus = document.activeElement instanceof HTMLElement ? document.activeElement : null;
    const dialog = document.querySelector<HTMLElement>(".destination-modal");
    const closeButton = dialog?.querySelector<HTMLButtonElement>(".modal-close");
    const getFocusable = () => Array.from(dialog?.querySelectorAll<HTMLElement>(
      'a[href], button:not([disabled]), input:not([disabled]), select:not([disabled]), textarea:not([disabled]), [tabindex]:not([tabindex="-1"])',
    ) ?? []).filter((element) => element.getClientRects().length > 0);
    const manageDialogKeys = (event: KeyboardEvent) => {
      if (event.key === "Escape") {
        setSelected(null);
        return;
      }
      if (event.key !== "Tab") return;
      const focusable = getFocusable();
      if (!focusable.length) {
        event.preventDefault();
        dialog?.focus();
        return;
      }
      const first = focusable[0];
      const last = focusable[focusable.length - 1];
      if (event.shiftKey && document.activeElement === first) {
        event.preventDefault();
        last.focus();
      } else if (!event.shiftKey && document.activeElement === last) {
        event.preventDefault();
        first.focus();
      }
    };
    document.body.style.overflow = "hidden";
    document.addEventListener("keydown", manageDialogKeys);
    requestAnimationFrame(() => closeButton?.focus());
    return () => {
      document.body.style.overflow = oldOverflow;
      document.removeEventListener("keydown", manageDialogKeys);
      if (previousFocus?.isConnected) previousFocus.focus({ preventScroll: true });
    };
  }, [selected]);

  const filtered = useMemo(() => {
    const term = search.trim().toLocaleLowerCase();
    return destinations.filter((destination) => {
      const matchesCountry = country === "All countries" || destination.country === country;
      const matchesCategory = category === "All experiences" || destination.category === category;
      const searchable = [destination.name, destination.country, destination.description, ...destination.highlights, ...destination.activities]
        .join(" ").toLocaleLowerCase();
      return matchesCountry && matchesCategory && (!term || searchable.includes(term));
    });
  }, [search, country, category]);

  const clearFilters = () => { setSearch(""); setCountry("All countries"); setCategory("All experiences"); };
  const credit = selected ? credits[selected.slug] : undefined;

  return (
    <section className="destination-section section-shell" id="destinations" aria-labelledby="destinations-heading">
      <div className="section-heading destination-heading">
        <div>
          <p className="eyebrow">The continent, thoughtfully explored</p>
          <h2 id="destinations-heading">Find your <em>Africa.</em></h2>
        </div>
        <p className="section-intro">From Atlantic history to Indian Ocean mornings, begin with a place that speaks to you.</p>
      </div>

      <div className="destination-tools" role="search" aria-label="Filter destinations">
        <label className="search-field">
          <Search size={18} aria-hidden="true" />
          <span className="sr-only">Search destinations</span>
          <input value={search} onChange={(event) => setSearch(event.target.value)} placeholder="Search a place, landscape or activity" />
          {search && <button className="clear-search" type="button" aria-label="Clear destination search" onClick={() => setSearch("")}><X size={16} /></button>}
        </label>
        <label className="country-select-wrap">
          <MapPin size={17} aria-hidden="true" />
          <span className="sr-only">Filter by country</span>
          <select value={country} onChange={(event) => setCountry(event.target.value)}>
            <option>All countries</option>
            {destinationCountries.map((item) => <option key={item}>{item}</option>)}
          </select>
          <ChevronDown size={16} aria-hidden="true" />
        </label>
      </div>

      <div className="category-chips" aria-label="Destination categories">
        {["All experiences", ...destinationCategories].map((item) => (
          <button key={item} type="button" className={`category-chip${category === item ? " is-active" : ""}`} aria-pressed={category === item} onClick={() => setCategory(item)}>{item}</button>
        ))}
      </div>

      <div className="results-line" aria-live="polite">
        <span><strong>{filtered.length}</strong> {filtered.length === 1 ? "place" : "places"} to explore</span>
        {(search || country !== "All countries" || category !== "All experiences") && <button type="button" className="text-button" onClick={clearFilters}>Clear filters</button>}
      </div>

      {filtered.length ? (
        <div className="destination-grid">
          {filtered.map((destination, index) => (
            <article className="destination-card" key={destination.slug}>
              <button className="destination-image-button" type="button" onClick={() => setSelected(destination)} aria-label={`Explore ${destination.name}`}>
                <img src={destination.image} alt={destination.imageAlt} loading="lazy" width="900" height="640" />
                <span className="image-category">{destination.category}</span>
                <span className="image-arrow" aria-hidden="true"><ArrowUpRight size={18} /></span>
              </button>
              <div className="destination-card-content">
                <div className="destination-meta"><span>{destination.region}</span><span aria-hidden="true">·</span><span>{destination.country}</span></div>
                <h3>{destination.name}</h3>
                <p>{destination.description}</p>
                <div className="destination-actions">
                  <button type="button" className="button button-quiet" onClick={() => setSelected(destination)}>Explore <ArrowRight size={15} /></button>
                  <button type="button" className="button button-outline" onClick={() => onBook(destination)}>Book <ArrowUpRight size={15} /></button>
                </div>
              </div>
            </article>
          ))}
        </div>
      ) : (
        <div className="empty-results">
          <p className="eyebrow">No matching places</p>
          <p>Try a different search or clear your filters to see all destinations.</p>
          <button type="button" className="button button-primary" onClick={clearFilters}>Show all destinations</button>
        </div>
      )}

      {selected && (
        <div className="modal-backdrop" role="presentation" onMouseDown={(event) => { if (event.target === event.currentTarget) setSelected(null); }}>
          <section className="destination-modal" role="dialog" aria-modal="true" aria-labelledby="destination-modal-title">
            <button className="modal-close" type="button" aria-label="Close destination details" onClick={() => setSelected(null)}><X size={20} /></button>
            <div className="modal-photo">
              <img src={selected.image} alt={selected.imageAlt} width="1200" height="820" />
              {credit && <a className="photo-credit" href={credit.source} target="_blank" rel="noreferrer" aria-label={`Photo ${credit.title} by ${credit.artist}, ${credit.license}. View original source`}>Photo: {credit.title} · {credit.artist} · {credit.license}</a>}
            </div>
            <div className="modal-copy">
              <p className="eyebrow">{selected.region} <span aria-hidden="true">·</span> {selected.country}</p>
              <h2 id="destination-modal-title">{selected.name}</h2>
              <p className="modal-description">{selected.description}</p>
              <div className="modal-detail-grid">
                <div><h3>Places to see</h3><ul>{selected.highlights.map((item) => <li key={item}>{item}</li>)}</ul></div>
                <div><h3>Ways to experience it</h3><ul>{selected.activities.map((item) => <li key={item}>{item}</li>)}</ul></div>
              </div>
              <button type="button" className="button button-primary modal-book" onClick={() => { setSelected(null); onBook(selected); }}>Plan this destination <ArrowUpRight size={16} /></button>
            </div>
          </section>
        </div>
      )}
    </section>
  );
}
