export type PackageType = "day_trips" | "group_trips" | "private_trips" | "hosted_trips";

export const bookingPlans: Array<{
  id: PackageType;
  title: string;
  eyebrow: string;
  description: string;
  icon: "day" | "group" | "private" | "hosted";
}> = [
  {
    id: "day_trips",
    title: "Day trips",
    eyebrow: "A day, well spent",
    description:
      "Our day trips are thoughtfully curated to give you the perfect balance of culture, adventure, relaxation, and unforgettable experiences. Whether you’re looking to explore historic landmarks, discover hidden gems, enjoy local cuisine, or immerse yourself in the vibrant energy of the destination, each experience is designed to create lasting memories while making the most of your time.",
    icon: "day",
  },
  {
    id: "group_trips",
    title: "Group trips",
    eyebrow: "Better together",
    description:
      "Experiences through Ghana and Africa are more meaningful when shared with the right community. Our curated group trips bring people together for cultural connection, adventure, and shared memories.",
    icon: "group",
  },
  {
    id: "private_trips",
    title: "Private trips",
    eyebrow: "Made personal",
    description:
      "A private trip allows us to create a personalized itinerary thoughtfully designed around your interests, preferences, and travel style. Every detail is curated for a seamless journey made just for you.",
    icon: "private",
  },
  {
    id: "hosted_trips",
    title: "Hosted trips",
    eyebrow: "Your people, your trip",
    description:
      "Host your own unforgettable trip with friends, family, or your community while we handle everything. We design seamless group travel experiences tailored to your vision.",
    icon: "hosted",
  },
];

export const legacyOffers = [
  {
    id: "essipong-beach-resort",
    plan: "day_trips" as const,
    title: "Essipong Beach Resort",
    eyebrow: "Day trip",
    description: "A comfortable place to regain energy",
    availability: "15 Slots",
    price: "$200.00",
    image: "/manus-storage/day-trips-1_f38c70a7.webp",
    detailUrl: "https://www.travelwithcuraters.com/trip-details.php?id=8",
  },
  {
    id: "axim-beach-day",
    plan: "day_trips" as const,
    title: "Axim Beach",
    eyebrow: "Day trip · Axim",
    description:
      "A great choice for a stay in Eikwe. You can splash around at the outdoor pool and visit one of the 4 restaurants for a bite to eat.",
    availability: "500 Slots",
    price: "$200.00",
    image: "/manus-storage/day-trips-2_c74753f4.webp",
    detailUrl: "https://www.travelwithcuraters.com/trip-details.php?id=5",
  },
  {
    id: "vernice-beach",
    plan: "day_trips" as const,
    title: "Vernice Beach",
    eyebrow: "Day trip · Eikwe",
    description:
      "Venice View Beach Resort is a great choice for a stay in Eikwe. You can splash around at the outdoor pool and visit one of the 4 restaurants for a bite to eat.",
    availability: "4 Slots",
    price: "$1.00",
    image: "/manus-storage/day-trips-3_c4af72af.webp",
    detailUrl: "https://www.travelwithcuraters.com/trip-details.php?id=3",
  },
  {
    id: "ghana-at-70",
    plan: "group_trips" as const,
    title: "GHANA @ 70",
    eyebrow: "Ghana group trip",
    description: "Ghana Group",
    availability: "9–15 People",
    status: "PENDING",
    price: "$6,000.00",
    image: "/manus-storage/group-trips-1_8b22e1df.webp",
    detailUrl: "https://www.travelwithcuraters.com/special-trip-details.php?id=22",
  },
  {
    id: "tenack-beach",
    plan: "group_trips" as const,
    title: "TENACK BEACH",
    eyebrow: "Eikwe group trip",
    description:
      "Situated on a huge palm covered tropical hillside that overlooks kilometres of deserted beaches, with luxury rooms, suites and apartments.",
    availability: "5–20 People",
    price: "$1.00",
    image: "/manus-storage/group-trips-1_8b22e1df.webp",
    detailUrl: "https://www.travelwithcuraters.com/special-trip-details.php?id=18",
  },
  {
    id: "axim-beach-hosted",
    plan: "hosted_trips" as const,
    title: "AXIM BEACH",
    eyebrow: "Hosted trip",
    description:
      "Situated on a huge palm covered tropical hillside that overlooks kilometres of deserted beaches, with luxury rooms, suites and apartments.",
    availability: "5–20 People",
    price: "$1.00",
    image: "/manus-storage/hosted-trips-1_bc2f3d3a.webp",
    detailUrl: "https://www.travelwithcuraters.com/special-trip-details.php?id=17",
  },
];
