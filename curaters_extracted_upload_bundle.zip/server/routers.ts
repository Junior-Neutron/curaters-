import { COOKIE_NAME } from "@shared/const";
import { nanoid } from "nanoid";
import { z } from "zod";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { createBookingRecord } from "./db";
import { publicProcedure, router } from "./_core/trpc";

const destinationNames = new Set([
  "Cape Coast Castle", "Kakum National Park", "Mole National Park", "Wli Waterfalls",
  "Maasai Mara", "Diani Beach", "Serengeti", "Mount Kilimanjaro", "Zanzibar",
  "Cape Town", "Table Mountain", "Kruger National Park", "The Egyptian Pyramids", "Luxor",
  "Marrakech", "Chefchaouen", "The Sahara Desert", "Victoria Falls",
  "Bwindi Impenetrable Forest", "Volcanoes National Park", "Sossusvlei", "Gorée Island",
]);

const isoDate = z.string().regex(/^\d{4}-\d{2}-\d{2}$/, "Use a valid date.").refine((value) => {
  const parsed = Date.parse(`${value}T00:00:00.000Z`);
  return Number.isFinite(parsed) && new Date(parsed).toISOString().slice(0, 10) === value;
}, "Use a valid date.");

const bookingInput = z.object({
  fullName: z.string().trim().min(2, "Enter your full name.").max(160),
  email: z.string().trim().email("Enter a valid email address.").max(320),
  phone: z.string().trim().min(5, "Enter a valid phone number.").max(48)
    .refine((value) => value.replace(/\D/g, "").length >= 7, "Enter a valid phone number."),
  country: z.string().trim().min(2, "Enter your country.").max(120),
  destination: z.string().refine((value) => destinationNames.has(value), "Choose a listed destination."),
  packageType: z.enum(["day_trips", "group_trips", "private_trips", "hosted_trips"]),
  travelStart: isoDate,
  travelEnd: isoDate,
  adults: z.number().int().min(1).max(30),
  children: z.number().int().min(0).max(30),
  accommodationPreference: z.string().trim().min(1).max(120),
  budget: z.string().trim().max(120).optional().default(""),
  activities: z.array(z.string().trim().min(1).max(100)).min(1, "Choose at least one activity.").max(15),
  specialRequests: z.string().trim().max(3000).optional().default(""),
  preferredContact: z.enum(["email", "phone", "whatsapp"]),
}).strict().superRefine((value, context) => {
  if (value.travelEnd < value.travelStart) {
    context.addIssue({ code: "custom", path: ["travelEnd"], message: "Return date must be on or after the start date." });
  }
});

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return { success: true } as const;
    }),
  }),
  bookings: router({
    create: publicProcedure.input(bookingInput).mutation(async ({ input }) => {
      const reference = `CUR-${nanoid(8).toUpperCase()}`;
      await createBookingRecord({
        reference,
        fullName: input.fullName,
        email: input.email,
        phone: input.phone,
        country: input.country,
        destination: input.destination,
        packageType: input.packageType,
        travelStart: input.travelStart,
        travelEnd: input.travelEnd,
        adults: input.adults,
        children: input.children,
        accommodationPreference: input.accommodationPreference,
        budget: input.budget || null,
        activities: JSON.stringify(input.activities),
        specialRequests: input.specialRequests || null,
        preferredContact: input.preferredContact,
      });
      return { reference };
    }),
  }),
});

export type AppRouter = typeof appRouter;
