import { useEffect, useState } from "react";
import { ArrowDown, ArrowLeft, ArrowRight, ArrowUp, ArrowUpRight, Instagram, Mail, MapPin, MoveUpRight } from "lucide-react";
import { destinations, type Destination } from "@/data/destinations";
import type { PackageType } from "@/data/travelPackages";
import SiteHeader from "@/components/SiteHeader";
import DestinationExplorer from "@/components/DestinationExplorer";
import JourneySection from "@/components/JourneySection";
import BookingForm from "@/components/BookingForm";
import FAQSection from "@/components/FAQSection";

const heroSlides = ["maasai-mara", "zanzibar", "victoria-falls", "sossusvlei", "cape-coast-castle"]
  .map((slug) => destinations.find((destination) => destination.slug === slug))
  .filter((destination): destination is Destination => Boolean(destination));

export default function Home() {
  const [slide, setSlide] = useState(0);
  const [bookingDestination, setBookingDestination] = useState<Destination | null>(null);
  const [bookingPlan, setBookingPlan] = useState<PackageType>("day_trips");
  const [showBackToTop, setShowBackToTop] = useState(false);
  const currentSlide = heroSlides[slide];

  useEffect(() => {
    const update = () => setShowBackToTop(window.scrollY > 620);
    update();
    window.addEventListener("scroll", update, { passive: true });
    return () => window.removeEventListener("scroll", update);
  }, []);

  function goToBooking(destination?: Destination, plan?: PackageType) {
    setBookingDestination(destination ? { ...destination } : null);
    if (plan) setBookingPlan(plan);
    else if (destination) setBookingPlan("day_trips");
    document.getElementById("book")?.scrollIntoView({ behavior: "smooth", block: "start" });
    window.requestAnimationFrame(() => document.getElementById("booking-heading")?.focus({ preventScroll: true }));
  }

  const moveSlide = (step: number) => setSlide((current) => (current + step + heroSlides.length) % heroSlides.length);

  return (
    <div className="site-root" id="top">
      <a className="skip-link" href="#main-content">Skip to content</a>
      <SiteHeader />
      <main id="main-content">
        <section className="hero-section" aria-labelledby="hero-title">
          <div className="hero-grain" aria-hidden="true" />
          <div className="hero-copy">
            <p className="eyebrow hero-eyebrow"><span className="eyebrow-line" /> Curated African travel experiences</p>
            <h1 id="hero-title">Go where<br />the story <em>stays.</em></h1>
            <p className="hero-description">Discover Africa through journeys shaped by place, people and the feeling you carry home.</p>
            <div className="hero-actions">
              <a className="button button-primary hero-primary" href="#destinations">Explore destinations <ArrowUpRight size={17} /></a>
              <button className="hero-secondary" type="button" onClick={() => goToBooking(undefined, "day_trips")}>Plan a trip <span aria-hidden="true">↗</span></button>
            </div>
            <a className="hero-scroll" href="#destinations"><span>Scroll to explore</span><ArrowDown size={15} /></a>
          </div>

          <div className="hero-visual" aria-roledescription="carousel" aria-label="Featured African destinations">
            <img className="hero-photo" key={currentSlide.slug} src={currentSlide.image} alt={currentSlide.imageAlt} fetchPriority="high" width="1200" height="900" />
            <div className="hero-photo-shade" />
            <div className="hero-photo-caption" aria-live="polite">
              <div><span className="hero-photo-kicker">Featured destination</span><h2>{currentSlide.name}</h2><p><MapPin size={14} /> {currentSlide.country}</p></div>
              <button type="button" className="hero-explore" onClick={() => document.getElementById("destinations")?.scrollIntoView({ behavior: "smooth" })} aria-label={`Explore ${currentSlide.name}`}><ArrowUpRight size={19} /></button>
            </div>
            <div className="hero-carousel-controls">
              <button type="button" aria-label="Previous featured destination" onClick={() => moveSlide(-1)}><ArrowLeft size={16} /></button>
              <div className="hero-dots" aria-label={`Slide ${slide + 1} of ${heroSlides.length}`}>
                {heroSlides.map((item, index) => <button key={item.slug} type="button" className={index === slide ? "is-active" : ""} aria-label={`Show ${item.name}`} aria-pressed={index === slide} onClick={() => setSlide(index)} />)}
              </div>
              <span className="hero-slide-count">{String(slide + 1).padStart(2, "0")} <span>/</span> {String(heroSlides.length).padStart(2, "0")}</span>
              <button type="button" aria-label="Next featured destination" onClick={() => moveSlide(1)}><ArrowRight size={16} /></button>
            </div>
            <span className="hero-photo-index" aria-hidden="true">{String(slide + 1).padStart(2, "0")}</span>
          </div>
        </section>

        <div className="intro-strip" aria-label="Travel philosophy">
          <span>Curated, not crowded</span><span className="intro-separator" aria-hidden="true">✳</span>
          <span>Rooted in place</span><span className="intro-separator" aria-hidden="true">✳</span>
          <span>Made to be remembered</span>
        </div>

        <DestinationExplorer onBook={(destination) => goToBooking(destination, "day_trips")} />
        <JourneySection onBook={(plan) => goToBooking(undefined, plan)} />

        <section className="story-section section-shell" id="story" aria-labelledby="story-heading">
          <div className="story-mark"><img src="/manus-storage/logo-wordmark-dark_a51733b7.png" alt="Curaters" width="1062" height="190" loading="lazy" /></div>
          <div className="story-copy">
            <p className="eyebrow">A way of seeing</p>
            <h2 id="story-heading">Travel, turned into <em>art.</em></h2>
            <p className="story-lead">Our vision is to turn travel into art, carefully curated, deeply felt, and impossible to forget.</p>
            <a className="story-link" href="mailto:travelcuraters@gmail.com">Tell us what moves you <ArrowUpRight size={16} /></a>
          </div>
          <div className="story-note"><span className="story-note-mark">C.</span><p>Curated African<br />travel experiences</p><span className="story-note-line" /></div>
        </section>

        <BookingForm
          initialDestination={bookingDestination}
          initialPackage={bookingPlan}
          onClearSelection={() => setBookingDestination(null)}
        />
        <FAQSection />
      </main>

      <footer className="site-footer">
        <div className="footer-main section-shell">
          <div className="footer-brand">
            <a className="footer-wordmark" href="#top" aria-label="Curaters home"><img className="footer-wordmark-image" src="/manus-storage/logo-wordmark-light_66658bd3.png" alt="Curaters" width="1062" height="190" /></a>
            <p>Curated African travel experiences</p>
            <p className="footer-vision">Our vision is to turn travel into art, carefully curated, deeply felt, and impossible to forget.</p>
          </div>
          <div className="footer-links">
            <div><p className="footer-label">Explore</p><a href="#destinations">Destinations</a><a href="#journeys">Journeys</a><a href="#book">Plan a trip</a></div>
            <div><p className="footer-label">Connect</p><a href="mailto:travelcuraters@gmail.com"><Mail size={15} /> Email Curaters</a><a href="https://www.instagram.com/curaters_" target="_blank" rel="noreferrer"><Instagram size={15} /> Instagram <MoveUpRight size={12} /></a><a href="https://www.tiktok.com/@curaters" target="_blank" rel="noreferrer"><span className="tiktok-mini" aria-hidden="true">♪</span> TikTok <MoveUpRight size={12} /></a></div>
          </div>
        </div>
        <div className="footer-legacy-links section-shell">
          <div><span className="footer-label">Company</span><a href="#story">Why Curaters</a><a href="https://www.travelwithcuraters.com/about-us.php" target="_blank" rel="noreferrer">Careers <MoveUpRight size={12} /></a></div>
          <div><span className="footer-label">Policies</span><a href="mailto:travelcuraters@gmail.com?subject=Request%20for%20Terms%20and%20Conditions">Terms and Conditions · request a copy</a><a href="mailto:travelcuraters@gmail.com?subject=Request%20for%20Privacy%20Policy">Privacy Policy · request a copy</a></div>
        </div>
        <div className="footer-bottom section-shell"><span>© Curaters 2026</span><span>Thoughtfully made for the places that stay with you.</span><a href="#top">Back to the beginning <ArrowUpRight size={13} /></a></div>
      </footer>

      {showBackToTop && <button className="back-to-top" type="button" onClick={() => window.scrollTo({ top: 0, behavior: "smooth" })} aria-label="Back to top"><ArrowUp size={18} /></button>}
      <a className="mobile-book-shortcut" href="#book"><span>Plan your trip</span><ArrowUpRight size={17} /></a>
    </div>
  );
}
