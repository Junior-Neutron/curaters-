# GitHub upload and deployment note

This project is a full-stack React/Vite + Node/Express application, not a plain static HTML site.

## Upload to GitHub
1. Extract this ZIP.
2. Create a new GitHub repository.
3. Upload the *contents* of this folder (so `package.json`, `client/`, `server/`, and `shared/` are at the repository root).
4. Commit the files.

## Important: GitHub Pages limitation
GitHub Pages only hosts static files. It cannot run this project's Node/Express backend, database migrations, or server-side API. A frontend-only static build may not provide the complete app.

To deploy the full application, use a Node.js hosting service that supports build/start commands and configure required environment variables and a database. The scripts in `package.json` include:
- Build: `pnpm build`
- Start: `pnpm start`

Review `README.md`, `.env.example` if present, and the server configuration before deploying. Do not upload real secrets, API keys, passwords, or a populated `.env` file to a public repository.
