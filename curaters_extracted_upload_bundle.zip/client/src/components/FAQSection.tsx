const faqs = [
  {
    question: "What kinds of trips can I plan with Curaters?",
    answer: "Choose from day trips, group trips, private trips, and hosted trips. Each option is described in the Journeys section, and the booking form lets you share the experience you have in mind.",
  },
  {
    question: "Can I ask for a trip shaped around my interests?",
    answer: "Yes. The private-trip description is built around your interests, preferences, and travel style. Use the activities and special-requests fields to share what matters to you.",
  },
  {
    question: "Does submitting the booking form confirm a reservation?",
    answer: "No. The form sends a trip request and provides a reference after it has been saved. That reference is not a confirmed reservation or a payment receipt.",
  },
  {
    question: "Can I include children or accommodation preferences?",
    answer: "Yes. Include the number of adults and children, and select the accommodation preference that best describes your request.",
  },
  {
    question: "How can I contact Curaters directly?",
    answer: "Email travelcuraters@gmail.com, or follow Curaters on Instagram and TikTok using the links in the footer.",
  },
];

export default function FAQSection() {
  return (
    <section className="faq-section section-shell" id="faq" aria-labelledby="faq-heading">
      <div className="section-heading faq-heading">
        <p className="eyebrow">A few good things to know</p>
        <h2 id="faq-heading">Questions, <em>answered.</em></h2>
        <p>Helpful details for the first step of your journey.</p>
      </div>
      <div className="faq-list">
        {faqs.map((faq, index) => (
          <details className="faq-item" key={faq.question} open={index === 0}>
            <summary>{faq.question}<span aria-hidden="true" className="faq-plus">+</span></summary>
            <p>{faq.answer}</p>
          </details>
        ))}
      </div>
    </section>
  );
}
